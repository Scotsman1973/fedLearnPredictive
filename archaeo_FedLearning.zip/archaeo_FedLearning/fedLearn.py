import pandas as pd
import os, glob, shutil

class FL():

    def __init__(self):
        ####################################
        self.combined_features = []
        self.combined_weights = []
        self.combined_feedback = []
        self.combined_occurances = []
        self.combined_crs = []
        self.combined_newWeights = []
        self.combined_newFeedback = []
        self.combined_new_occurances = []
        self.weightXoccurances = []
        self.newWeightXnewOccurances = []
        self.SumOccurances = []
        self.new_weight = []

        self.globalModel_df = pd.DataFrame()
        #####################################

    def fedLearn(self):

        self.path = r"C:\Users\s5353503\data\FL_data\global_model"
        #create folder called temp inside the path chosen by user
        directory = 'temp'
        pathForFolder = os.path.join(self.path, directory)
        accessPermissions = 0o777#readable and writeable by all
        os.mkdir(pathForFolder, accessPermissions)
        GM_path = r"{}\GM.csv".format(self.path)
        #thanks to this answer for directions for the next five lines
        #https://stackoverflow.com/questions/62330833/pandas-split-dataframe-by-unique-column-value
        GM_df = pd.read_csv(GM_path)
        # df[column].unique() returns a list of unique values in that particular column
        for crs in GM_df['crs'].unique():
            # Filter the dataframe using that column and value from the list
            GM_df[GM_df['crs'] == crs].to_csv( r"{}\temp\{}.csv".format(self.path, crs) )

        os.remove(GM_path)
        #this routine cleans each csv and resets the index correctly
        df_names = []
        wildcard_path = r"{}\temp\*.csv".format(self.path)
        files = glob.glob(wildcard_path)
        for file in files:
            df = pd.read_csv( file )
            name = os.path.splitext(os.path.basename("{}".format(file) ) ) [0]
            features = df['Landscape feature'].tolist()
            weights = df['Weight'].tolist()
            feedbacks = df['Feedback'].tolist()
            occurances = df['Occurances'].tolist()
            crsList = df['crs'].tolist()

            model = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
            model.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']

            os.remove(file)
            model.to_csv(file)

        #use cleaned up files for weighted averaging learning
            global_model_path = r"{}\{}.csv".format(self.path, name)

            if os.path.exists(global_model_path):
                global_model = pd.read_csv( global_model_path )
                features = global_model['Landscape feature'].tolist()
                weights = global_model['Weight'].tolist()
                feedbacks = global_model['Feedback'].tolist()
                occurances = global_model['Occurances'].tolist()
                crsList = global_model['crs'].tolist()

                global_model = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
                global_model.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']

                #routine to create the dataframe for weighted average learning
                for i, globalModel_row in global_model.iterrows():
                    for j, model_row in model.iterrows():
                        if globalModel_row['Landscape feature'] == model_row['Landscape feature']:
                            self.combined_features.append(globalModel_row['Landscape feature'])
                            self.combined_weights.append(globalModel_row['Weight'])
                            self.combined_feedback.append(globalModel_row['Feedback'])
                            self.combined_occurances.append(globalModel_row['Occurances'])
                            self.combined_crs.append(globalModel_row['crs'])
                            self.combined_newWeights.append(model_row['Weight'])
                            self.combined_newFeedback.append(model_row['Feedback'])
                            self.combined_new_occurances.append(model_row['Occurances'])
    
                self.globalModel_df['Landscape feature'] = pd.Series(self.combined_features)
                self.globalModel_df['Weight'] = pd.Series(self.combined_weights)
                self.globalModel_df['Feedback'] = pd.Series(self.combined_feedback)#using pd.Series allows NaN constructions
                self.globalModel_df['Occurances'] = pd.Series(self.combined_occurances)
                self.globalModel_df['crs'] = pd.Series(self.combined_crs)
                self.globalModel_df['New weight'] = pd.Series(self.combined_newWeights)
                self.globalModel_df['New feedback'] = pd.Series(self.combined_newFeedback)
                self.globalModel_df['New Occurances'] = pd.Series(self.combined_new_occurances)

                for i, globalModel_df_row in self.globalModel_df.iterrows():
                    self.SumOccurances.append(globalModel_df_row['Occurances'] + globalModel_df_row['New Occurances'])
                    weight_1 = globalModel_df_row['Weight'] * globalModel_df_row['Occurances']
                    weight_2 = globalModel_df_row['New weight'] * globalModel_df_row['New Occurances']
                    Sum_occur = globalModel_df_row['Occurances'] + globalModel_df_row['New Occurances']
                    self.new_weight.append( (weight_1 + weight_2) / Sum_occur )

                self.globalModel_df['Occurances'] = pd.Series(self.SumOccurances)
                self.globalModel_df['Weight'] = pd.Series(self.new_weight)

                print('combined dataframe')
                print(self.globalModel_df)
                ###################################drop columns didn't work so have to choose columns wanted
                features = self.globalModel_df['Landscape feature'].tolist()
                weights = self.globalModel_df['Weight'].tolist()
                feedbacks = self.globalModel_df['Feedback'].tolist()
                occurances = self.globalModel_df['Occurances'].tolist()
                crsList = self.globalModel_df['crs'].tolist()

                self.new_global_model = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
                self.new_global_model.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']
                self.new_global_model.to_csv(r"{}\{}.csv".format(self.path, name))
                print(self.new_global_model)
            else:
                model.to_csv(r"{}\{}.csv".format(self.path, name))

        #remove 'temp' folder for next batch of data
        shutil.rmtree( r"{}\temp".format(self.path) , ignore_errors=True)