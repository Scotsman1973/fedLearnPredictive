# importing module
import pandas as pd
import os

class RL():

    def __init__(self, crs, newData, path2plugin):
        self.plugInPath = path2plugin
        self.crs = crs
        self.new_data = newData
        self.local_model_path = r"{pluginPath}\local_model\{crs}.csv".format(pluginPath = self.plugInPath, crs = self.crs)

    ##########################################################
    def isLMtest(self):
        self.newInLocalList_features = []
        self.newInLocalList_weights = []
        self.newInLocalList_feedback = []
        self.newInLocalList_newWeights = []
        self.newInLocalList_newFeedback = []
        self.newInLocalList_occurances = []
        self.newInLocalList_new_occurances = []
        self.newInLocalList_crs = []
        #############
        self.extraWeightList_1 = []
        self.extraWeightList_2 = []
        self.total_feedback = []
        self.diff_Weights_list = []
        self.new_diff_Weights_list = []
        self.occurances_list = []
        self.newOccurances = []
        ##############################
        #self.new_data = pd.read_csv(r"C:\Users\s5353503\data\FL_data\predictive_models\{crs}\{file_name}.csv".format(crs = '27700', file_name = 'four') )
        #create dataframe
        self.newInLocalModel_df = pd.DataFrame(columns=  ['Landscape feature', 'Weight', 'Feedback'])
        self.InLocalModel_df = pd.DataFrame(columns=  ['Landscape feature', 'Weight', 'Feedback'])
        ################################
        if os.path.exists(self.local_model_path):
            self.local_model = pd.read_csv( self.local_model_path )
            self.features = self.local_model['Landscape feature'].tolist()
            self.weights = self.local_model['Weight'].tolist()
            self.feedbacks = self.local_model['Feedback'].tolist()
            self.occurances = self.local_model['Occurances'].tolist()
            self.crsList = self.local_model['crs'].tolist()

            self.local_model = pd.DataFrame(list(zip(self.features, self.weights, self.feedbacks, self.occurances, self.crsList) ) )
            self.local_model.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']
            self.reinforceLearn()
        else:
            self.local_model = self.new_data
            self.outputLM()
        return

    def reinforceLearn(self):
        for i, localModel_row in self.local_model.iterrows():
            for j, new_data_row in self.new_data.iterrows():
                if localModel_row['Landscape feature'] == new_data_row['Landscape feature']:
                    self.newInLocalList_features.append(localModel_row['Landscape feature'])
                    self.newInLocalList_weights.append(localModel_row['Weight'])
                    self.newInLocalList_feedback.append(localModel_row['Feedback'])
                    self.newInLocalList_occurances.append(localModel_row['Occurances'])
                    self.newInLocalList_crs.append(localModel_row['crs'])
                    self.newInLocalList_newWeights.append(new_data_row['Weight'])
                    self.newInLocalList_newFeedback.append(new_data_row['Feedback'])
                    self.newInLocalList_new_occurances.append(new_data_row['Occurances'])
        self.onlyInLocalModel = self.local_model
        self.onlyInNewData = self.new_data
        #this dataframe has those entries only in the local model
        #this data will just be placed back into the dataframe
        for feat in self.newInLocalList_features:            
            dropRowIndex = self.onlyInLocalModel.index[self.onlyInLocalModel['Landscape feature'] == feat].tolist()
            for index in dropRowIndex:
                self.onlyInLocalModel.drop(index, inplace= True)
        #this dataframe has those entries only in new data
        for feat in self.newInLocalList_features:            
            dropRowIndex = self.onlyInNewData.index[self.onlyInNewData['Landscape feature'] == feat].tolist()
            for index in dropRowIndex:
                self.onlyInNewData.drop(index, inplace= True)
        #create dataframe to do reinforcement learning on
        self.newInLocalModel_df['Landscape feature'] = pd.Series(self.newInLocalList_features)
        self.newInLocalModel_df['Weight'] = pd.Series(self.newInLocalList_weights)
        self.newInLocalModel_df['Feedback'] = pd.Series(self.newInLocalList_feedback)#using pd.Series allows NaN constructions
        self.newInLocalModel_df['Occurances'] = pd.Series(self.newInLocalList_occurances)
        self.newInLocalModel_df['crs'] = pd.Series(self.newInLocalList_crs)
        self.newInLocalModel_df['New weight'] = pd.Series(self.newInLocalList_newWeights)
        self.newInLocalModel_df['New feedback'] = pd.Series(self.newInLocalList_newFeedback)
        self.newInLocalModel_df['New Occurances'] = pd.Series(self.newInLocalList_new_occurances)

        for i, row in self.newInLocalModel_df.iterrows():#iterate through dataframe
            self.feedback_total = row['Feedback'] + row['New feedback']
            self.weight_diff = abs( row['Weight'] - row['New weight'] )#always positive
            self.total_feedback.append(self.feedback_total)
            self.diff_Weights_list.append(self.weight_diff)
            self.newInLocalModel_df.at[i, 'Occurances'] = row['Occurances'] + row['New Occurances']

        for i, row in self.newInLocalModel_df.iterrows():#iterate through dataframe
            self.extra_weight = self.diff_Weights_list[i]/self.total_feedback[i]
            self.weight = self.extra_weight * row['Feedback']
            self.extraWeightList_1.append( round( self.weight, 2) )

        for i, row in self.newInLocalModel_df.iterrows():#iterate through dataframe
            self.extra_weight = self.diff_Weights_list[i]/self.total_feedback[i]
            self.weight = self.extra_weight * row['New feedback']
            self.extraWeightList_2.append(  round( self.weight, 2))

        #self.newInLocalModel_df['Weights diff'] = pd.Series(self.diff_Weights_list)#using pd.Series allows NaN constructions
        self.newInLocalModel_df['Extra weight List 1'] = pd.Series(self.extraWeightList_1)
        self.newInLocalModel_df['Extra weight List 2'] = pd.Series(self.extraWeightList_2)
        #print(self.newInLocalModel_df)

        for i, row in self.newInLocalModel_df.iterrows():#iterate through dataframe
            if row['Weight'] == row['New weight']:
                self.newInLocalModel_df.at[i, 'Weight'] = row['New weight']
        #loop in with test for weight being higher or lower than new weight
        #do we use weight list one or two, and do we add or subtract
            elif row['Feedback'] < row['New feedback']:#extraWeight_2 because new feedback higher
                if row['Weight'] > row['New weight']:
                    self.newInLocalModel_df.at[i, 'Weight'] = row['New weight'] + self.extraWeightList_1[i]#subtract to move it down towards
                else:
                    self.newInLocalModel_df.at[i, 'Weight'] = row['Weight'] + self.extraWeightList_2[i]#add to move it up towards

            elif row['Feedback'] > row['New feedback']:#both these have been checked
                if row['Weight'] > row['New weight']:
                    self.newInLocalModel_df.at[i, 'Weight'] = row['Weight'] - self.extraWeightList_2[i]#subtract to move it down towards
                else:
                    self.newInLocalModel_df.at[i, 'Weight'] = row['New weight'] - self.extraWeightList_1[i]#
            else:
                pass

        for i, row in self.newInLocalModel_df.iterrows():#iterate through dataframe
            if row['Weight'] == row['New weight']:
                self.newInLocalModel_df.at[i, 'Feedback'] = max(row['Feedback'], row['New feedback'])
            else:
                self.newInLocalModel_df.at[i, 'Feedback'] = ( row['Feedback'] + row['New feedback'] )/2
        #################################################
        self.features = self.newInLocalModel_df['Landscape feature'].tolist()
        self.weights = self.newInLocalModel_df['Weight'].tolist()
        self.feedbacks = self.newInLocalModel_df['Feedback'].tolist()
        self.newOccurances = self.newInLocalModel_df['Occurances'].tolist()
        self.LMcrs = self.newInLocalModel_df['crs'].tolist()
        ###################
        self.InLocalModel_df['Landscape feature'] = pd.Series(self.features)
        self.InLocalModel_df['Weight'] = pd.Series(self.weights)
        self.InLocalModel_df['crs'] = pd.Series(self.LMcrs)
        self.InLocalModel_df['Feedback'] = pd.Series(self.feedbacks)#using pd.Series allows NaN constructions
        self.InLocalModel_df['Occurances'] = pd.Series(self.newOccurances)
        ################################################
        self.local_model = pd.concat([self.InLocalModel_df, self.onlyInLocalModel, self.onlyInNewData], ignore_index=True, axis = 0)
        self.local_model.drop_duplicates(inplace=True, subset=['Landscape feature'] )
        self.local_model = self.local_model.reset_index(drop=True)
        self.outputLM()
        return

    def outputLM(self):
        print('local model')
        print(self.local_model)
        self.local_model.to_csv(self.local_model_path)
        return