import pyautogui

print( pyautogui.size() )