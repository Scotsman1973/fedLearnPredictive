import socket, os
import threading
import pandas as pd
import struct
from federateLearn import FL

def receive_file_size(sck: socket.socket):
    # This funcion makes sure that the bytes which indicate
    # the size of the file that will be sent are received.
    # The file is packed by the client via struct.pack(),
    # a function that generates a bytes sequence that
    # represents the file size.
    fmt = "<Q"
    expected_bytes = struct.calcsize(fmt)
    received_bytes = 0
    stream = bytes()
    while received_bytes < expected_bytes:
        chunk = sck.recv(expected_bytes - received_bytes)
        stream += chunk
        received_bytes += len(chunk)
    filesize = struct.unpack(fmt, stream)[0]
    return filesize

def handle_client(client_socket, addr):
    BUFFER_SIZE = 1024
    # First read from the socket the amount of
    # bytes that will be received from the file.
    filesize = receive_file_size(client_socket)
    # Open a new file where to store the received data.
    with open(r"C:\Users\s5353503\data\FL_data\global_model\GM.csv", "wb") as f:
        received_bytes = 0
        # Receive the file data in 1024-bytes chunks
        # until reaching the total amount of bytes
        # that was informed by the client.
        while received_bytes < filesize:
            chunk = client_socket.recv(BUFFER_SIZE)
            if chunk:
                f.write(chunk)
                received_bytes += len(chunk)

    ###############fed learning
    fedLearning = FL()
    fedLearning.fedLearn()
    #######################################

def run_server():
    # receive 4096 bytes each time
    
    server_ip = "127.0.0.1"  # server hostname or IP address
    port = 8000  # server port number
    # create a socket object
    try:
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # bind the socket to the host and port
        server.bind((server_ip, port))
        # listen for incoming connections
        server.listen(5)
        print(f"Listening on {server_ip}:{port}")

        while True:
            # accept a client connection
            client_socket, addr = server.accept()
            print(f"Accepted connection from {addr[0]}:{addr[1]}")
            # start a new thread to handle the client
            thread = threading.Thread(target=handle_client, args=(client_socket, addr,))
            thread.start()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        server.close()


run_server()

