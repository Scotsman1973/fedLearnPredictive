import pandas as pd
import os, glob, shutil

class FL():

    def __init__(self):
        ####################################
        #self.working_df = pd.DataFrame()
        #self.replacement_df = pd.DataFrame()
        self.path = r"C:\Users\s5353503\data\FL_data\global_model"
        #####################################
    def fedLearn(self):

        self.path = r"C:\Users\s5353503\data\FL_data\global_model"
        #create folder called temp inside the path chosen by user
        directory = 'temp'
        pathForFolder = os.path.join(self.path, directory)
        accessPermissions = 0o777#readable and writeable by all
        os.mkdir(pathForFolder, accessPermissions)
        GM_path = r"{}\GM.csv".format(self.path)
        #thanks to this answer for directions for the next five lines
        #https://stackoverflow.com/questions/62330833/pandas-split-dataframe-by-unique-column-value
        GM_df = pd.read_csv(GM_path)
        # df[column].unique() returns a list of unique values in that particular column
        for crs in GM_df['crs'].unique():
            # Filter the dataframe using that column and value from the list
            GM_df[GM_df['crs'] == crs].to_csv( r"{}\temp\{}.csv".format(self.path, crs) )

        os.remove(GM_path)

        #this routine cleans each csv and resets the index correctly
        self.new_file_names = []
        wildcard_path = r"{}\temp\*.csv".format(self.path)
        files = glob.glob(wildcard_path)
        for file in files:
            self.name = os.path.splitext(os.path.basename("{}".format(file) ) ) [0]
            self.new_file_names.append(self.name)
            #print(self.name)#works to here
            df = pd.read_csv( file )
            features = df['Landscape feature'].tolist()
            weights = df['Weight'].tolist()
            feedbacks = df['Feedback'].tolist()
            occurances = df['Occurances'].tolist()
            crsList = df['crs'].tolist()

            model = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
            model.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']
            #print(model)
            os.remove(file)
            model.to_csv( r"{}\temp\{}.csv".format(self.path, self.name))

        self.model_file_names = []
        wildcard_path = r"{}\*.csv".format(self.path)
        files = glob.glob(wildcard_path)
        for file in files:
            self.model_name = os.path.splitext(os.path.basename("{}".format(file) ) ) [0]
            self.model_file_names.append(self.model_name)

        self.update = []
        self.move = []
        for element in self.new_file_names:
            if element in self.model_file_names:
                self.update.append(element)
            else:
                self.move.append(element)

        print('update list')
        print(self.update)
        print('move list')
        print(self.move)
        #########################
        if len(self.move) > 0:#tests for contents
            for file in self.move:
                shutil.move(  r"{}\temp\{}.csv".format(self.path, file), r"{}\{}.csv".format(self.path, file) )
        else:
            pass
        
        
        for file in self.update:
            #need to define lists inside loop to clean them on each iteration
            self.combined_features = []
            self.combined_weights = []
            self.combined_feedback = []
            self.combined_occurances = []
            self.combined_crs = []
            self.combined_newWeights = []
            self.combined_newFeedback = []
            self.combined_new_occurances = []
            self.weightXoccurances = []
            self.newWeightXnewOccurances = []
            self.SumOccurances = []
            self.new_weight = []
            self.working_df = pd.DataFrame()
            self.replacement_df = pd.DataFrame()
            #####################################################################
            new_df = pd.read_csv( r"{}\temp\{}.csv".format(self.path, file) )
            features = new_df['Landscape feature'].tolist()
            weights = new_df['Weight'].tolist()
            feedbacks = new_df['Feedback'].tolist()
            occurances = new_df['Occurances'].tolist()
            crsList = new_df['crs'].tolist()

            newData = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
            newData.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']
            
            print('new data')
            print(file)
            print(newData.shape )
#########################################################################################################
            LM_df = pd.read_csv( r"{}\{}.csv".format(self.path, file) )
            features = LM_df['Landscape feature'].tolist()
            weights = LM_df['Weight'].tolist()
            feedbacks = LM_df['Feedback'].tolist()
            occurances = LM_df['Occurances'].tolist()
            crsList = LM_df['crs'].tolist()

            LM_Data = pd.DataFrame(list(zip(features, weights, feedbacks, occurances, crsList) ) )
            LM_Data.columns = ['Landscape feature', 'Weight', 'Feedback', 'Occurances', 'crs']
           
            print('model')
            print(LM_Data.shape )
            ##########################
            for i, newData_row in newData.iterrows(): #checks each row of new data
                for j, LM_Data_row in LM_Data.iterrows():
                    if newData_row['Landscape feature'] == LM_Data_row['Landscape feature']:
                        self.combined_features.append(newData_row['Landscape feature'])
                        self.combined_weights.append(newData_row['Weight'])
                        self.combined_feedback.append(newData_row['Feedback'])
                        self.combined_occurances.append(newData_row['Occurances'])
                        self.combined_crs.append(newData_row['crs'])
                        self.combined_newWeights.append(LM_Data_row['Weight'])
                        self.combined_newFeedback.append(LM_Data_row['Feedback'])
                        self.combined_new_occurances.append(LM_Data_row['Occurances'])

            self.working_df['Landscape feature'] = pd.Series(self.combined_features)
            self.working_df['Weight'] = pd.Series(self.combined_weights)
            self.working_df['Feedback'] = pd.Series(self.combined_feedback)#using pd.Series allows NaN constructions
            self.working_df['Occurances'] = pd.Series(self.combined_occurances)
            self.working_df['crs'] = pd.Series(self.combined_crs)
            self.working_df['New weight'] = pd.Series(self.combined_newWeights)
            self.working_df['New feedback'] = pd.Series(self.combined_newFeedback)
            self.working_df['New Occurances'] = pd.Series(self.combined_new_occurances)
            print(self.working_df)
            for i, working_df_row in self.working_df.iterrows():
                self.SumOccurances.append(working_df_row['Occurances'] + working_df_row['New Occurances'])
                weight_1 = working_df_row['Weight'] * working_df_row['Occurances']
                weight_2 = working_df_row['New weight'] * working_df_row['New Occurances']
                Sum_occur = working_df_row['Occurances'] + working_df_row['New Occurances']
                weight = (weight_1 + weight_2) / Sum_occur
                self.new_weight.append( round(weight, 2) )

            self.working_df['Occurances'] = pd.Series(self.SumOccurances)
            self.working_df['Weight'] = pd.Series(self.new_weight)

            self.onlyInNewData = newData
            self.onlyInLMdata = LM_Data
            #this data will just be placed back into the dataframe
            for feat in self.combined_features:            
                dropRowIndex = self.onlyInLMdata.index[self.onlyInLMdata['Landscape feature'] == feat].tolist()
                for index in dropRowIndex:
                    self.onlyInLMdata.drop(index, inplace= True)
            #this dataframe has those entries only in new data
            for feat in self.combined_features:            
                dropRowIndex = self.onlyInNewData.index[self.onlyInNewData['Landscape feature'] == feat].tolist()
                for index in dropRowIndex:
                    self.onlyInNewData.drop(index, inplace= True)

            self.replacement_df['Landscape feature'] = pd.Series(self.combined_features)
            self.replacement_df['Weight'] = pd.Series(self.new_weight)
            self.replacement_df['Feedback'] = pd.Series(self.combined_feedback)#using pd.Series allows NaN constructions
            self.replacement_df['Occurances'] = pd.Series(self.SumOccurances)
            self.replacement_df['crs'] = pd.Series(self.combined_crs)

            self.replacement_df = pd.concat([self.replacement_df, self.onlyInLMdata, self.onlyInNewData], ignore_index=True, axis = 0)
            #####################
            #drop duplicates based on landform type, ignore the rest
            self.replacement_df.drop_duplicates(inplace=True, subset=['Landscape feature'] )
            self.replacement_df.to_csv(r"{}\{}.csv".format(self.path, file))
            self.replacement_df = self.replacement_df.reset_index(drop=True)

            print(self.replacement_df)
        shutil.rmtree( r"{}\temp".format(self.path) , ignore_errors=True)