import socket
from federateLearn import FL

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

ip = 'localhost'
port = 8080

#bind server address to ip and port
server_address = (ip, port)
server.bind(server_address)
#listen for data on ip and port specified
server.listen()

print('waiting for connection')
client, addr = server.accept()#accept any data sent from client

file = open(r'C:\Users\s5353503\data\FL_data\global_model\GM.csv', "wb")
file_bytes = b""
finished = False

while not finished:#infinite loop until finished is true
    data = client.recv(1024)

    if file_bytes[-5:] == b"<END>":
        file_bytes = file_bytes[:-5]
        finished = True
    else:
        file_bytes += data

file.write(file_bytes)
print('received')
file.close()
###############fed learning
fedLearning = FL()
fedLearning.fedLearn()
#######################################
client.close()
server.close()